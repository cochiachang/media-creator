---
name: run-viral-analyzer
description: Analyze video SRT subtitles; split into segments with viral potential scores, key phrases, keywords, and titles. Output CSV. Use for viral highlight analysis.
compatibility: Requires OPENAI_API_KEY, output/*.srt
---

# 爆紅精華片段分析器

讀取 `output/` 內的 `.srt` 字幕檔，結合 `短影音爆紅入門全攻略.md` 的方法論，透過 GPT-4o 將全片從頭到尾拆成語意完整的最小可擷取段落，對每一段分析爆紅潛力，輸出完整 CSV 報告。

Input：`output/<file>.srt`
Output：`output/<file>_viral_segments.csv`

## Run（agent path）
互動步驟：
1. 若 `output/` 有多個 `.srt` 檔，輸入編號選擇
2. 若外部未傳入，詢問使用者：**影片背景資訊**（主題、主角身份、品牌等）
3. 將全片字幕從頭到尾依語意邊界拆成**最小可擷取段落**：
   - 每段須語意完整、可獨立成一支短影音
   - 段落不重疊、不遺漏，**全片內容 100% 被覆蓋**
   - 片段數量不限，依內容自然拆分
4. 對每一段進行爆紅潛力分析（評分 1–10），**不篩選、不刪除任何片段**
5. 依片段在影片中的出現順序排列（由前到後）
6. CSV 自動儲存至 `output/<filename>_viral_segments.csv`，包含全部片段

## CSV 輸出格式

固定欄位（UTF-8 BOM，可直接用 Excel 開啟）：

| 欄位 | 說明 |
|---|---|
| 片段編號 | 依影片時序由前到後排列 |
| 開始時間 | HH:MM:SS,mmm |
| 結束時間 | HH:MM:SS,mmm |
| 完整字幕內容 | 該片段所有字幕原文，完整保留，不截斷 |
| 爆紅潛力評分 | 1–10（10 最高） |
| 爆紅關鍵句 | 該片段中最有爆紅爆點的一句話（原文） |
| 爆紅原因 | 具體說明為何有（或沒有）爆紅潛力 |
